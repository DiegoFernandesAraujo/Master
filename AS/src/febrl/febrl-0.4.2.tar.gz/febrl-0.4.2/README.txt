Febrl (Freely extensible biomedical record linkage) Version 0.4.2

Copyright 2002 - 2011 Australian National University and others.
All Rights reserved.

See the file ANUOS-1.3.txt or the manual for the terms under which
the computer program code and associated documentation and data files
in the Febrl package are licensed.


Peter Christen, 14 December 2011.
