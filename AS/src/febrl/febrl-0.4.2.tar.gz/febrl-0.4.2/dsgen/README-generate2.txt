README for version 2 of Febrl data set generator      Peter Christen, December 2008
------------------------------------------------

Version 2 (generate2) of this generator now include field dependencies, the
possibilities to model phonetic, OCR and typographical modifications, as well
as to generate family and household data.

These functionalities are in an 'alpha' state and have received limited testing.
They have been implemented by Agus Pudjijono as part of his MComp (Honours)
research project at the ANU in 2008. For more detailed descriptions please see:

  Probabilistic Data Generation
  Agus Pudjijono
  Master of Computing (Honours) thesis,
  ANU Department of Computer Science, November 2008. 

as available from:

  http://datamining.anu.edu.au/projects/linkage-publications.html
